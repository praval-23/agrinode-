"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupabaseCommerceRepository = void 0;
const supabaseClient_1 = require("./supabaseClient");
function fail(error, operation) {
    if (error)
        throw new Error(`Supabase ${operation} failed: ${error.message}`);
    throw new Error(`Supabase ${operation} failed`);
}
function requiredString(row, key) { return String(row[key] ?? ''); }
function numberValue(row, key) { return Number(row[key] ?? 0); }
function mapListing(row) {
    return {
        id: requiredString(row, 'id'), farmerId: requiredString(row, 'farmer_id'), crop: requiredString(row, 'crop'), grade: requiredString(row, 'grade'),
        quantityKg: numberValue(row, 'quantity_kg'), availableQuantityKg: numberValue(row, 'available_quantity_kg'), pricePerKg: numberValue(row, 'price_per_kg'),
        harvestDate: requiredString(row, 'harvest_date'), location: requiredString(row, 'location'), description: requiredString(row, 'description'),
        status: row.status, createdAt: requiredString(row, 'created_at'), verified: Boolean(row.verified),
        qualityScore: row.quality_score === null || row.quality_score === undefined ? undefined : numberValue(row, 'quality_score'),
        qualityConfidence: row.quality_confidence === null || row.quality_confidence === undefined ? undefined : numberValue(row, 'quality_confidence'),
        scanSource: row.scan_source === 'gemini' || row.scan_source === 'mock' ? row.scan_source : undefined,
    };
}
function mapOrder(row) {
    return {
        id: requiredString(row, 'id'), buyerId: requiredString(row, 'buyer_id'), farmerId: requiredString(row, 'farmer_id'), listingId: requiredString(row, 'listing_id'),
        crop: requiredString(row, 'crop'), quantityKg: numberValue(row, 'quantity_kg'), pricePerKg: numberValue(row, 'price_per_kg'), totalAmount: numberValue(row, 'total_amount'),
        status: row.status, createdAt: requiredString(row, 'created_at'), deliveryLocation: requiredString(row, 'delivery_location'),
        paymentStatus: row.payment_status, transportStatus: row.transport_status, grade: requiredString(row, 'grade'),
    };
}
function mapSettlement(row) {
    return { id: requiredString(row, 'id'), orderId: requiredString(row, 'order_id'), totalAmount: numberValue(row, 'total_amount'), farmerAmount: numberValue(row, 'farmer_amount'), transporterAmount: numberValue(row, 'transporter_amount'), serviceNodeAmount: numberValue(row, 'service_node_amount'), status: row.status, actualTransfer: false, createdAt: requiredString(row, 'created_at') };
}
function mapLogistics(row) {
    return { orderId: requiredString(row, 'order_id'), status: row.status, transporterId: row.transporter_id ? String(row.transporter_id) : undefined, pickupLocation: requiredString(row, 'pickup_location'), deliveryLocation: requiredString(row, 'delivery_location'), provider: 'demo', routeStatus: row.route_status, routeSummary: row.route_summary ? String(row.route_summary) : undefined };
}
class SupabaseCommerceRepository {
    get client() { return (0, supabaseClient_1.getSupabaseClient)(); }
    async ensureProfile(id, role) {
        const { error } = await this.client.from('profiles').upsert({ id, role }, { onConflict: 'id', ignoreDuplicates: true });
        if (error)
            fail(error, 'profile upsert');
    }
    async listListings(status) {
        let query = this.client.from('listings').select('*').order('created_at', { ascending: false });
        if (status)
            query = query.eq('status', status);
        const { data, error } = await query;
        if (error)
            fail(error, 'list listings');
        return (data ?? []).map((row) => mapListing(row));
    }
    async getListing(listingId) {
        const { data, error } = await this.client.from('listings').select('*').eq('id', listingId).maybeSingle();
        if (error)
            fail(error, 'get listing');
        return data ? mapListing(data) : undefined;
    }
    async createListing(input) {
        await this.ensureProfile(input.farmerId, 'farmer');
        const row = { ...input, available_quantity_kg: input.quantityKg, status: 'ACTIVE', verified: false };
        const { data, error } = await this.client.from('listings').insert({ id: `LST-${crypto.randomUUID()}`, farmer_id: input.farmerId, crop: input.crop, grade: input.grade, quantity_kg: input.quantityKg, available_quantity_kg: input.quantityKg, price_per_kg: input.pricePerKg, harvest_date: input.harvestDate, location: input.location, description: input.description, status: 'ACTIVE', verified: false, quality_score: input.qualityScore ?? null, quality_confidence: input.qualityConfidence ?? null, scan_source: input.scanSource ?? null }).select().single();
        void row;
        if (error || !data)
            fail(error, 'create listing');
        return mapListing(data);
    }
    async updateListing(listingId, patch) {
        const update = {};
        if (patch.crop !== undefined)
            update.crop = patch.crop;
        if (patch.grade !== undefined)
            update.grade = patch.grade;
        if (patch.quantityKg !== undefined)
            update.quantity_kg = patch.quantityKg;
        if (patch.pricePerKg !== undefined)
            update.price_per_kg = patch.pricePerKg;
        if (patch.harvestDate !== undefined)
            update.harvest_date = patch.harvestDate;
        if (patch.location !== undefined)
            update.location = patch.location;
        if (patch.description !== undefined)
            update.description = patch.description;
        const { data, error } = await this.client.from('listings').update(update).eq('id', listingId).select().maybeSingle();
        if (error)
            fail(error, 'update listing');
        return data ? mapListing(data) : undefined;
    }
    async listOrders(filters) {
        let query = this.client.from('orders').select('*').order('created_at', { ascending: false });
        if (filters.buyerId)
            query = query.eq('buyer_id', filters.buyerId);
        if (filters.farmerId)
            query = query.eq('farmer_id', filters.farmerId);
        const { data, error } = await query;
        if (error)
            fail(error, 'list orders');
        return (data ?? []).map((row) => mapOrder(row));
    }
    async getOrder(orderId) {
        const { data, error } = await this.client.from('orders').select('*').eq('id', orderId).maybeSingle();
        if (error)
            fail(error, 'get order');
        return data ? mapOrder(data) : undefined;
    }
    async createOrder(input) {
        await this.ensureProfile(input.buyerId, 'buyer');
        const { data, error } = await this.client.rpc('reserve_listing_and_create_order', { p_buyer_id: input.buyerId, p_listing_id: input.listingId, p_quantity_kg: input.quantityKg, p_delivery_location: input.deliveryLocation });
        if (error) {
            if (error.message.includes('LISTING_NOT_AVAILABLE') || error.message.includes('INSUFFICIENT_QUANTITY'))
                return { error: error.message };
            fail(error, 'create order');
        }
        const result = data;
        return { order: mapOrder(result.order), settlement: mapSettlement(result.settlement), logistics: mapLogistics(result.logistics) };
    }
    async updateOrderStatus(orderId, status) {
        const transportStatus = status === 'PICKUP_ASSIGNED' ? 'ASSIGNED' : status === 'IN_TRANSIT' ? 'IN_TRANSIT' : status === 'DELIVERED' ? 'DELIVERED' : undefined;
        const update = { status, ...(transportStatus ? { transport_status: transportStatus } : {}), ...(status === 'COMPLETED' ? { payment_status: 'SETTLED_DEMO' } : {}) };
        const { data, error } = await this.client.from('orders').update(update).eq('id', orderId).select().maybeSingle();
        if (error)
            fail(error, 'update order status');
        if (!data)
            return undefined;
        if (transportStatus)
            await this.client.from('logistics').update({ status: transportStatus }).eq('order_id', orderId);
        return mapOrder(data);
    }
    async getSettlement(orderId) {
        const { data, error } = await this.client.from('settlements').select('*').eq('order_id', orderId).maybeSingle();
        if (error)
            fail(error, 'get settlement');
        return data ? mapSettlement(data) : undefined;
    }
    async getLogistics(orderId) {
        const { data, error } = await this.client.from('logistics').select('*').eq('order_id', orderId).maybeSingle();
        if (error)
            fail(error, 'get logistics');
        return data ? mapLogistics(data) : undefined;
    }
    async updateSettlementStatus(orderId, status) {
        const { data, error } = await this.client.from('settlements').update({ status }).eq('order_id', orderId).select().maybeSingle();
        if (error)
            fail(error, 'update settlement');
        return data ? mapSettlement(data) : undefined;
    }
    async updateLogistics(orderId, update) {
        const row = { ...(update.status ? { status: update.status } : {}), ...(update.transporterId ? { transporter_id: update.transporterId } : {}), ...(update.routeStatus ? { route_status: update.routeStatus } : {}), ...(update.routeSummary ? { route_summary: update.routeSummary } : {}) };
        const { data, error } = await this.client.from('logistics').update(row).eq('order_id', orderId).select().maybeSingle();
        if (error)
            fail(error, 'update logistics');
        return data ? mapLogistics(data) : undefined;
    }
}
exports.SupabaseCommerceRepository = SupabaseCommerceRepository;
