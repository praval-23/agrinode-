"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listListings = listListings;
exports.getListing = getListing;
exports.createListing = createListing;
exports.updateListing = updateListing;
exports.listOrders = listOrders;
exports.getOrder = getOrder;
exports.createOrder = createOrder;
exports.updateOrderStatus = updateOrderStatus;
exports.getSettlement = getSettlement;
exports.getLogistics = getLogistics;
exports.updateSettlementStatus = updateSettlementStatus;
exports.updateLogistics = updateLogistics;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const statePath = (0, node_path_1.join)(process.cwd(), 'data', 'agri-state.json');
const emptyState = { listings: [], orders: [], settlements: [], logistics: [] };
function loadState() {
    try {
        if (!(0, node_fs_1.existsSync)(statePath))
            return structuredClone(emptyState);
        const parsed = JSON.parse((0, node_fs_1.readFileSync)(statePath, 'utf8'));
        return { listings: parsed.listings ?? [], orders: parsed.orders ?? [], settlements: parsed.settlements ?? [], logistics: parsed.logistics ?? [] };
    }
    catch {
        return structuredClone(emptyState);
    }
}
let state = loadState();
function persist() {
    (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(statePath), { recursive: true });
    (0, node_fs_1.writeFileSync)(statePath, JSON.stringify(state, null, 2), 'utf8');
}
function id(prefix) { return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; }
function listListings(status) {
    return state.listings.filter((listing) => !status || listing.status === status);
}
function getListing(listingId) { return state.listings.find((listing) => listing.id === listingId); }
function createListing(input) {
    const listing = { ...input, id: id('LST'), availableQuantityKg: input.quantityKg, status: 'ACTIVE', createdAt: new Date().toISOString(), verified: false };
    state.listings.unshift(listing);
    persist();
    return listing;
}
function updateListing(listingId, patch) {
    const listing = getListing(listingId);
    if (!listing)
        return undefined;
    Object.assign(listing, patch);
    if (patch.quantityKg !== undefined)
        listing.availableQuantityKg = Math.min(listing.availableQuantityKg, patch.quantityKg);
    persist();
    return listing;
}
function listOrders(filters) {
    return state.orders.filter((order) => (!filters.buyerId || order.buyerId === filters.buyerId) && (!filters.farmerId || order.farmerId === filters.farmerId));
}
function getOrder(orderId) { return state.orders.find((order) => order.id === orderId); }
function createOrder(input) {
    const listing = getListing(input.listingId);
    if (!listing || listing.status !== 'ACTIVE')
        return { error: 'Listing is not available' };
    if (input.quantityKg > listing.availableQuantityKg)
        return { error: 'Requested quantity exceeds available quantity' };
    listing.availableQuantityKg -= input.quantityKg;
    if (listing.availableQuantityKg === 0)
        listing.status = 'SOLD';
    const totalAmount = Math.round(input.quantityKg * listing.pricePerKg * 100) / 100;
    const order = { id: id('ORD'), buyerId: input.buyerId, farmerId: listing.farmerId, listingId: listing.id, crop: listing.crop, quantityKg: input.quantityKg, pricePerKg: listing.pricePerKg, totalAmount, status: 'PLACED', createdAt: new Date().toISOString(), deliveryLocation: input.deliveryLocation, paymentStatus: 'PENDING', transportStatus: 'NOT_ASSIGNED', grade: listing.grade };
    const settlement = { id: id('SET'), orderId: order.id, totalAmount, farmerAmount: round(totalAmount * 0.85), transporterAmount: round(totalAmount * 0.10), serviceNodeAmount: round(totalAmount - round(totalAmount * 0.85) - round(totalAmount * 0.10)), status: 'PENDING', actualTransfer: false, createdAt: new Date().toISOString() };
    const logistics = { orderId: order.id, status: 'NOT_ASSIGNED', pickupLocation: listing.location, deliveryLocation: input.deliveryLocation, provider: 'demo', routeStatus: 'NOT_CALCULATED' };
    state.orders.unshift(order);
    state.settlements.unshift(settlement);
    state.logistics.unshift(logistics);
    persist();
    return { order, settlement, logistics };
}
function round(value) { return Math.round(value * 100) / 100; }
function updateOrderStatus(orderId, status) {
    const order = getOrder(orderId);
    if (!order)
        return undefined;
    order.status = status;
    if (status === 'PICKUP_ASSIGNED')
        order.transportStatus = 'ASSIGNED';
    if (status === 'IN_TRANSIT')
        order.transportStatus = 'IN_TRANSIT';
    if (status === 'DELIVERED')
        order.transportStatus = 'DELIVERED';
    if (status === 'COMPLETED')
        order.paymentStatus = 'SETTLED_DEMO';
    const shipment = state.logistics.find((item) => item.orderId === orderId);
    if (shipment)
        shipment.status = order.transportStatus;
    persist();
    return order;
}
function getSettlement(orderId) { return state.settlements.find((item) => item.orderId === orderId); }
function getLogistics(orderId) { return state.logistics.find((item) => item.orderId === orderId); }
function updateSettlementStatus(orderId, status) {
    const settlement = getSettlement(orderId);
    if (!settlement)
        return undefined;
    settlement.status = status;
    persist();
    return settlement;
}
function updateLogistics(orderId, update) {
    const logistics = getLogistics(orderId);
    if (!logistics)
        return undefined;
    Object.assign(logistics, update);
    persist();
    return logistics;
}
