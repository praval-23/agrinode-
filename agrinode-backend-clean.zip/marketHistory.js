"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildMarketHistory = buildMarketHistory;
const marketDiversification_1 = require("./marketDiversification");
function round(value) {
    return Math.round(value * 100) / 100;
}
function sameMarket(left, market) {
    return left.market.trim().toLowerCase() === market.trim().toLowerCase();
}
function betterRecord(left, right) {
    const leftDate = (0, marketDiversification_1.parseArrivalDate)(left.date) ?? Number.NEGATIVE_INFINITY;
    const rightDate = (0, marketDiversification_1.parseArrivalDate)(right.date) ?? Number.NEGATIVE_INFINITY;
    if (left.normalizedPricePerKg > 0 && right.normalizedPricePerKg <= 0)
        return left;
    if (right.normalizedPricePerKg > 0 && left.normalizedPricePerKg <= 0)
        return right;
    return leftDate >= rightDate ? left : right;
}
function buildMarketHistory(records, options) {
    const commodity = (0, marketDiversification_1.commodityKey)(options.commodity);
    const matching = records.filter((record) => (0, marketDiversification_1.commodityKey)(record.commodity) === commodity && (!options.market || sameMarket(record, options.market)) && record.normalizedPricePerKg > 0 && (0, marketDiversification_1.parseArrivalDate)(record.date) !== null);
    const byDate = new Map();
    for (const record of matching) {
        const existing = byDate.get(record.date);
        byDate.set(record.date, existing ? betterRecord(existing, record) : record);
    }
    const ordered = [...byDate.values()].sort((left, right) => ((0, marketDiversification_1.parseArrivalDate)(left.date) ?? 0) - ((0, marketDiversification_1.parseArrivalDate)(right.date) ?? 0));
    const latestDate = (0, marketDiversification_1.parseArrivalDate)(ordered.at(-1)?.date ?? '') ?? null;
    const minimumDate = latestDate === null ? null : latestDate - Math.max(1, options.days) * 24 * 60 * 60 * 1000;
    const points = ordered.filter((record) => minimumDate === null || ((0, marketDiversification_1.parseArrivalDate)(record.date) ?? 0) >= minimumDate).map((record) => ({ date: record.date, price: round(record.normalizedPricePerKg) }));
    const current = points.at(-1)?.price ?? null;
    const previous = points.length > 1 ? points.at(-2).price : null;
    const change = current !== null && previous !== null ? round(current - previous) : null;
    const changePercent = change !== null && previous !== null && previous !== 0 ? round((change / previous) * 100) : null;
    return { commodity: options.commodity, market: options.market ?? ordered.at(-1)?.market ?? '', currentPrice: current, previousPrice: previous, change, changePercent, history: points, demand: null, source: options.source, locationScope: options.locationScope };
}
