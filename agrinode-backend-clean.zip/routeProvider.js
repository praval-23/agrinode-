"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.demoRouteProvider = void 0;
exports.createDemoRoute = createDemoRoute;
exports.demoRouteProvider = {
    name: 'demo',
    createRoute: () => 'Demo route: pickup and destination recorded; live distance and GPS are not configured.',
};
function createDemoRoute() { return exports.demoRouteProvider.createRoute(); }
