"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseProvider = exports.commerceRepository = void 0;
exports.getDatabaseStatus = getDatabaseStatus;
const env_1 = require("../config/env");
const localCommerceRepository_1 = require("./localCommerceRepository");
const supabaseClient_1 = require("./supabaseClient");
const supabaseCommerceRepository_1 = require("./supabaseCommerceRepository");
exports.commerceRepository = env_1.env.database.provider === 'supabase'
    ? new supabaseCommerceRepository_1.SupabaseCommerceRepository()
    : new localCommerceRepository_1.LocalJsonCommerceRepository();
exports.databaseProvider = env_1.env.database.provider;
async function getDatabaseStatus() {
    if (exports.databaseProvider !== 'supabase')
        return { databaseProvider: exports.databaseProvider, databaseStatus: 'local' };
    return { databaseProvider: exports.databaseProvider, databaseStatus: await (0, supabaseClient_1.checkSupabaseConnection)() ? 'connected' : 'unavailable' };
}
