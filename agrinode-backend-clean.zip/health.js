"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const repositories_1 = require("../repositories");
const healthRouter = (0, express_1.Router)();
healthRouter.get('/', async (_request, response) => {
    const database = await (0, repositories_1.getDatabaseStatus)();
    response.json({ status: 'ok', service: 'AgriNode API', ...database });
});
exports.default = healthRouter;
