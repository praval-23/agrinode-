"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const commerce_1 = __importDefault(require("./routes/commerce"));
const health_1 = __importDefault(require("./routes/health"));
const market_1 = __importDefault(require("./routes/market"));
const scan_1 = __importDefault(require("./routes/scan"));
exports.app = (0, express_1.default)();
// Camera captures arrive as base64 JSON bodies; give the scan route a larger limit.
// Must run BEFORE the global json parser (body-parser skips once the body is parsed).
exports.app.use('/api/scan', express_1.default.json({ limit: '8mb' }));
exports.app.use(express_1.default.json());
exports.app.use('/api/health', health_1.default);
exports.app.use('/api/market', market_1.default);
exports.app.use('/api/scan', scan_1.default);
exports.app.use('/api', commerce_1.default);
exports.app.use((error, _request, response, _next) => {
    console.error(error);
    const isPayloadTooLarge = typeof error === 'object' && error !== null && 'type' in error && error.type === 'entity.too.large';
    if (isPayloadTooLarge) {
        response.status(413).json({ error: 'Request body is too large' });
        return;
    }
    response.status(500).json({ error: 'Internal server error' });
});
