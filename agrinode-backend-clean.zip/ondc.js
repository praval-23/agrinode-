"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ondcAdapter = void 0;
/** Integration-ready mapping boundary. No ONDC network calls are made by this prototype. */
exports.ondcAdapter = {
    mapListingToCatalog: (listing) => ({ providerId: listing.farmerId, itemId: listing.id, descriptor: listing.crop, pricePerKg: listing.pricePerKg, availableQuantityKg: listing.availableQuantityKg }),
    mapOrderToNetwork: (order) => ({ orderId: order.id, itemId: order.listingId, buyerId: order.buyerId, sellerId: order.farmerId }),
    mapOrderStatus: (status) => status === 'CANCELLED' ? 'Cancelled' : status === 'COMPLETED' ? 'Completed' : status === 'PLACED' ? 'Created' : status === 'DELIVERED' ? 'Completed' : status === 'IN_TRANSIT' ? 'In-progress' : 'Accepted',
    syncOrder: async () => ({ integrated: false, reason: 'ONDC network credentials and callbacks are not configured' }),
};
