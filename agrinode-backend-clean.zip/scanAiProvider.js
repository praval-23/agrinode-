"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockScanProvider = exports.GeminiScanProvider = void 0;
exports.createScanAiProvider = createScanAiProvider;
const env_1 = require("../config/env");
const scan_1 = require("../types/scan");
function clampPercent(value, fallback) {
    const numeric = typeof value === 'number' ? value : Number(value);
    if (!Number.isFinite(numeric))
        return fallback;
    return Math.max(0, Math.min(100, Math.round(numeric)));
}
function clampMultiplier(value) {
    const numeric = typeof value === 'number' ? value : Number(value);
    if (!Number.isFinite(numeric))
        return undefined;
    return Math.max(0.7, Math.min(1.3, Math.round(numeric * 100) / 100));
}
/**
 * Only values the adapter itself derives are trusted from the model; every model-provided
 * field passes through narrowing + clamping so a malformed response cannot leak through.
 */
function toScanAnalysis(raw, model) {
    if (typeof raw !== 'object' || raw === null) {
        throw new scan_1.ScanProviderError('invalid_response', 'AI response is not an object');
    }
    const record = raw;
    const isCropPhoto = record.isCropPhoto === true;
    if (!isCropPhoto) {
        const reason = typeof record.notCropReason === 'string' && record.notCropReason.trim()
            ? record.notCropReason.trim()
            : 'The image does not clearly show a crop or produce.';
        throw new scan_1.ScanProviderError('not_crop', reason);
    }
    const cropRecord = (typeof record.crop === 'object' && record.crop !== null ? record.crop : {});
    const cropName = typeof cropRecord.name === 'string' && cropRecord.name.trim() ? cropRecord.name.trim() : 'Unknown crop';
    const scientificName = typeof cropRecord.scientificName === 'string' && cropRecord.scientificName.trim() ? cropRecord.scientificName.trim() : undefined;
    const qualityRecord = (typeof record.quality === 'object' && record.quality !== null ? record.quality : {});
    const gradeRaw = typeof qualityRecord.grade === 'string' ? qualityRecord.grade.trim().toUpperCase() : '';
    const grade = gradeRaw === 'A' || gradeRaw === 'B' || gradeRaw === 'C' ? gradeRaw : 'B';
    const score = clampPercent(qualityRecord.score, 50);
    const qualityConfidence = clampPercent(qualityRecord.confidence, 50);
    const issueTypes = ['disease', 'pest', 'nutrient_deficiency', 'quality_defect'];
    const severities = ['low', 'medium', 'high'];
    const issues = Array.isArray(record.issues)
        ? record.issues.slice(0, 8).flatMap((entry) => {
            if (typeof entry !== 'object' || entry === null)
                return [];
            const issue = entry;
            const name = typeof issue.name === 'string' && issue.name.trim() ? issue.name.trim() : undefined;
            if (!name)
                return [];
            const type = issueTypes.find((candidate) => candidate === issue.type) ?? 'quality_defect';
            const severity = severities.find((candidate) => candidate === issue.severity) ?? 'low';
            return [{
                    type,
                    name,
                    severity,
                    confidence: clampPercent(issue.confidence, 50),
                    description: typeof issue.description === 'string' ? issue.description.trim() : '',
                    treatment: typeof issue.treatment === 'string' ? issue.treatment.trim() : '',
                }];
        })
        : [];
    const observations = Array.isArray(record.observations)
        ? record.observations.filter((entry) => typeof entry === 'string' && entry.trim().length > 0).map((entry) => entry.trim()).slice(0, 10)
        : [];
    const cropConfidence = clampPercent(cropRecord.confidence, 50);
    const multiplier = clampMultiplier(record.recommendedPriceMultiplier);
    return {
        isCropPhoto: true,
        crop: { name: cropName, scientificName, confidence: cropConfidence },
        quality: { grade, score, confidence: qualityConfidence },
        issues,
        observations,
        ...(multiplier !== undefined ? { recommendedPriceMultiplier: multiplier } : {}),
        scannedAt: new Date().toISOString(),
        model,
    };
}
const SCAN_PROMPT = `You are an agricultural produce quality inspector for an Indian farmer marketplace app.
Analyze the attached photo and respond with JSON only.

Rules:
- If the image does not clearly show a crop, fruit, vegetable, grain, or harvested produce, set isCropPhoto=false and put a short helpful explanation in notCropReason. Do not guess a crop.
- Identify the crop when possible. If unsure of the exact variety, still give the closest confident crop name.
- Assess harvest/post-harvest quality: color, uniformity, visible damage, bruising, spots, mold, pests.
- Detect likely diseases, pests, or nutrient deficiencies only when there are visible signs. If identification is uncertain, say so in the description and lower the confidence. Never claim certainty from a photo alone.
- Frame treatment as cautious guidance (cultural practices, consulting a local agri officer). Never give pesticide dosages, brand names with quantities, or dangerous chemical instructions.
- Grade A = excellent/unblemished, B = minor cosmetic issues, C = significant damage or decay.
- IMPORTANT: every confidence and score value (crop.confidence, quality.score, quality.confidence, issues[].confidence) MUST be an integer between 0 and 100, expressed as a percent. Never use a 0-to-1 scale.
- recommendedPriceMultiplier: 0.7-1.3, how this lot's price should compare to the standard market rate for the crop.
- observations: short bullet-style strings about visible quality traits.`;
const SCAN_RESPONSE_SCHEMA = {
    type: 'object',
    properties: {
        isCropPhoto: { type: 'boolean' },
        notCropReason: { type: 'string', nullable: true },
        crop: {
            type: 'object',
            properties: {
                name: { type: 'string' },
                scientificName: { type: 'string', nullable: true },
                confidence: { type: 'number' },
            },
            required: ['name', 'confidence'],
        },
        quality: {
            type: 'object',
            properties: {
                grade: { type: 'string', enum: ['A', 'B', 'C'] },
                score: { type: 'number' },
                confidence: { type: 'number' },
            },
            required: ['grade', 'score', 'confidence'],
        },
        issues: {
            type: 'array',
            items: {
                type: 'object',
                properties: {
                    type: { type: 'string', enum: ['disease', 'pest', 'nutrient_deficiency', 'quality_defect'] },
                    name: { type: 'string' },
                    severity: { type: 'string', enum: ['low', 'medium', 'high'] },
                    confidence: { type: 'number' },
                    description: { type: 'string' },
                    treatment: { type: 'string' },
                },
                required: ['type', 'name', 'severity', 'confidence', 'description', 'treatment'],
            },
        },
        observations: { type: 'array', items: { type: 'string' } },
        recommendedPriceMultiplier: { type: 'number', nullable: true },
    },
    required: ['isCropPhoto', 'crop', 'quality', 'issues', 'observations'],
};
class GeminiScanProvider {
    name = 'gemini';
    async analyzeImage(imageBase64) {
        if (!env_1.scanEnv.gemini.apiKey) {
            throw new scan_1.ScanProviderError('configuration', 'GEMINI_API_KEY is required for the Gemini scan provider');
        }
        const url = `${env_1.scanEnv.gemini.apiBaseUrl}/models/${env_1.scanEnv.model}:generateContent`;
        const body = {
            contents: [{
                    parts: [
                        { text: SCAN_PROMPT },
                        { inline_data: { mime_type: 'image/jpeg', data: imageBase64 } },
                    ],
                }],
            generationConfig: {
                temperature: 0.2,
                responseMimeType: 'application/json',
                responseSchema: SCAN_RESPONSE_SCHEMA,
            },
        };
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), env_1.scanEnv.gemini.timeoutMs);
        try {
            if (process.env.NODE_ENV !== 'production') {
                console.info('[scan] Gemini request', { model: env_1.scanEnv.model, imageBytes: Math.round((imageBase64.length * 3) / 4), timeoutMs: env_1.scanEnv.gemini.timeoutMs });
            }
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env_1.scanEnv.gemini.apiKey },
                body: JSON.stringify(body),
                signal: controller.signal,
            });
            if (response.status === 429)
                throw new scan_1.ScanProviderError('rate_limit', 'Gemini API rate limit exceeded');
            if (response.status === 400 || response.status === 401 || response.status === 403) {
                // Surface the API's own reason (e.g. undecodable image) — never echo request contents or credentials.
                let detail = '';
                try {
                    const errBody = await response.json();
                    detail = typeof errBody.error?.message === 'string' ? `: ${errBody.error.message.slice(0, 200)}` : '';
                }
                catch {
                    // keep generic message if the body is unreadable
                }
                throw new scan_1.ScanProviderError('configuration', `Gemini API rejected the request (${response.status})${detail}`);
            }
            if (!response.ok)
                throw new scan_1.ScanProviderError('request', `Gemini API request failed (${response.status})`);
            const payload = await response.json();
            const text = payload.candidates?.[0]?.content?.parts?.map((part) => part.text ?? '').join('') ?? '';
            if (!text.trim())
                throw new scan_1.ScanProviderError('invalid_response', 'Gemini returned an empty response');
            let raw;
            try {
                raw = JSON.parse(text);
            }
            catch {
                throw new scan_1.ScanProviderError('invalid_response', 'Gemini response was not valid JSON');
            }
            return toScanAnalysis(raw, env_1.scanEnv.model);
        }
        catch (error) {
            if (error instanceof scan_1.ScanProviderError)
                throw error;
            if (error instanceof DOMException && error.name === 'AbortError') {
                throw new scan_1.ScanProviderError('timeout', `Gemini API timed out after ${env_1.scanEnv.gemini.timeoutMs}ms`);
            }
            throw new scan_1.ScanProviderError('request', error instanceof Error ? error.message : 'Gemini API request failed');
        }
        finally {
            clearTimeout(timeout);
        }
    }
}
exports.GeminiScanProvider = GeminiScanProvider;
/** Deterministic demo analyzer used when no provider is configured, plus as explicit fallback. */
class MockScanProvider {
    name = 'mock';
    async analyzeImage(_imageBase64) {
        await new Promise((resolve) => setTimeout(resolve, 600));
        return {
            isCropPhoto: true,
            crop: { name: 'Tomato', scientificName: 'Solanum lycopersicum', confidence: 94 },
            quality: { grade: 'A', score: 92, confidence: 94 },
            issues: [],
            observations: ['Good color', 'Good uniformity', 'Low visible damage'],
            recommendedPriceMultiplier: 1.08,
            scannedAt: new Date().toISOString(),
            model: 'mock-analyzer',
        };
    }
}
exports.MockScanProvider = MockScanProvider;
function createScanAiProvider() {
    if (env_1.scanEnv.provider === 'gemini')
        return new GeminiScanProvider();
    return new MockScanProvider();
}
