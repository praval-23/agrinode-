"use strict";
/**
 * AI scanner contract shared by the backend route and provider adapters.
 * Mirrors what the Expo app receives from POST /api/scan/quality.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScanProviderError = void 0;
class ScanProviderError extends Error {
    kind;
    constructor(kind, message) {
        super(message);
        this.kind = kind;
        this.name = 'ScanProviderError';
    }
}
exports.ScanProviderError = ScanProviderError;
