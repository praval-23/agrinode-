"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSupabaseClient = getSupabaseClient;
exports.checkSupabaseConnection = checkSupabaseConnection;
const supabase_js_1 = require("@supabase/supabase-js");
const env_1 = require("../config/env");
let client;
function getSupabaseClient() {
    if (env_1.env.database.provider !== 'supabase')
        throw new Error('Supabase database provider is not enabled');
    if (!env_1.env.database.supabaseUrl || !env_1.env.database.supabaseServiceRoleKey) {
        throw new Error('SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required when DATABASE_PROVIDER=supabase');
    }
    client ??= (0, supabase_js_1.createClient)(env_1.env.database.supabaseUrl, env_1.env.database.supabaseServiceRoleKey, {
        auth: { autoRefreshToken: false, persistSession: false },
    });
    return client;
}
async function checkSupabaseConnection() {
    try {
        const { error } = await getSupabaseClient().from('profiles').select('id', { head: true, count: 'exact' });
        return !error;
    }
    catch {
        return false;
    }
}
