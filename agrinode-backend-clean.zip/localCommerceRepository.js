"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalJsonCommerceRepository = void 0;
const commerceRepository_1 = require("../services/commerceRepository");
class LocalJsonCommerceRepository {
    listListings(status) { return Promise.resolve((0, commerceRepository_1.listListings)(status)); }
    getListing(listingId) { return Promise.resolve((0, commerceRepository_1.getListing)(listingId)); }
    createListing(input) { return Promise.resolve((0, commerceRepository_1.createListing)(input)); }
    updateListing(listingId, patch) { return Promise.resolve((0, commerceRepository_1.updateListing)(listingId, patch)); }
    listOrders(filters) { return Promise.resolve((0, commerceRepository_1.listOrders)(filters)); }
    getOrder(orderId) { return Promise.resolve((0, commerceRepository_1.getOrder)(orderId)); }
    createOrder(input) { return Promise.resolve((0, commerceRepository_1.createOrder)(input)); }
    updateOrderStatus(orderId, status) { return Promise.resolve((0, commerceRepository_1.updateOrderStatus)(orderId, status)); }
    getSettlement(orderId) { return Promise.resolve((0, commerceRepository_1.getSettlement)(orderId)); }
    getLogistics(orderId) { return Promise.resolve((0, commerceRepository_1.getLogistics)(orderId)); }
    updateSettlementStatus(orderId, status) { return Promise.resolve((0, commerceRepository_1.updateSettlementStatus)(orderId, status)); }
    updateLogistics(orderId, update) { return Promise.resolve((0, commerceRepository_1.updateLogistics)(orderId, update)); }
}
exports.LocalJsonCommerceRepository = LocalJsonCommerceRepository;
