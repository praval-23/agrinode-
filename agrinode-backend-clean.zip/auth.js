"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticate = authenticate;
exports.currentUser = currentUser;
const env_1 = require("../config/env");
function authenticate(request, response, next) {
    const header = request.header('authorization');
    if (!header) {
        if (env_1.env.auth.required) {
            response.status(401).json({ error: 'Authorization is required' });
            return;
        }
        next();
        return;
    }
    const [scheme, token] = header.split(' ');
    const user = scheme?.toLowerCase() === 'bearer' && token ? env_1.env.auth.tokens.get(token) : undefined;
    if (!user) {
        response.status(401).json({ error: 'Invalid authorization token' });
        return;
    }
    request.user = user;
    next();
}
function currentUser(request) {
    return request.user;
}
